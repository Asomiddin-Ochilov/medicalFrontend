import React, { useMemo, useState } from "react";
import { Avatar, Dropdown,Modal } from "antd";
import { useNavigate } from "react-router-dom";
import {SettingOutlined,
  LogoutOutlined,  BellOutlined, MoonOutlined, GlobalOutlined } from "@ant-design/icons";
import "../styles/navbar.css";
import img from '../pages/avatar.webp'
export default function Navbar({ title = "" }) {
  const [lang, setLang] = useState(localStorage.getItem("med_lang") || "uzb");
  const [userData, setUserData] = useState(JSON.parse(localStorage.getItem('userData')));
  console.log(userData);
  

  const onLangClick = ({ key }) => {
    setLang(key);
    localStorage.setItem("med_lang", key);
  };
  const navigate = useNavigate();


const handleUserMenuClick = ({ key }) => {
  if (key === "settings") {
    navigate("/settings");
  }

  if (key === "logout") {
    Modal.confirm({
      title: "Chiqmoqchimisiz?",
      okText: "Ha, chiqaman",
      cancelText: "Bekor qilish",
      okType: "danger", // qizil button
      onOk: () => {
        localStorage.removeItem("med_auth_token");
      localStorage.removeItem("userData");
      localStorage.removeItem('admin_id')
        navigate("/login");
      },
    });
  }
};


 const Dropitems = [
  {
    key: "settings",
    icon: <SettingOutlined />,
    label: "Sozlamalar",
  },
  {
    type: "divider",
  },
  {
    key: "logout",
    icon: <LogoutOutlined />,
    danger: true,
    label: "Chiqish",
  },
];

  const items = useMemo(() => {
    const langs = [
      { key: "uzb", text: "O‘zbek" },
      { key: "ru", text: "Русский" },
      { key: "en", text: "English" },
    ];

    return langs.map((l) => ({
      key: l.key,
      label: (
        <div className="lang-item">
          <span className={`lang-check ${lang === l.key ? "on" : ""}`}>✓</span>
          <span className="lang-label">{l.text}</span>
        </div>
      ),
    }));
  }, [lang]);

  return (
    <div className="topbar">
      <div className="topbar-title-pill">
        <span className="topbar-title">{title || " "}</span>
      </div>

      <div className="topbar-right">
        <div className="topbar-icons">
          <button className="topbar-ico-btn" type="button" title="Rejim">
            <MoonOutlined />
          </button>

          <button className="topbar-ico-btn" type="button" title="Bildirishnoma">
            <BellOutlined />
          </button>

          <Dropdown
            menu={{ items, onClick: onLangClick }}
            trigger={["click"]}
            placement="bottomRight"
          >
            <button className="topbar-lang-btn" type="button" title="Til">
              <GlobalOutlined />
              <span className="topbar-lang-text">{lang}</span>
            </button>
          </Dropdown>
        </div>

      <div className="topbar-user">
<Dropdown
  menu={{
    items: Dropitems,
    onClick: handleUserMenuClick,
  }}
  trigger={["click"]}
  placement="bottomRight"
>
  <div className="topbar-user-box">
    <Avatar size={48} src={img} />
    <div className="topbar-user-text">
      <div className="topbar-user-name">{userData?.username}</div>
      <div className="topbar-user-role">{userData?.position}</div>
    </div>
  </div>
</Dropdown>

</div>

      </div>
    </div>
  );
}
