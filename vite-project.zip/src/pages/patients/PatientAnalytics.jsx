
import "./patient-analytics.css";

import React, { useState } from 'react';

const DentalPage = () => {

const [selectedTeeth, setSelectedTeeth] = useState({
  extraction: [47],
  filling: [32],
  crown: [14]
});

const prices = {
  extraction: 200000,
  filling: 150000,
  crown: 200000
};

// ✅ FUNKSIYA AVVAL
const calculatePrice = (category) => {
  const count = selectedTeeth[category].length;
  return count * prices[category];
};

// ✅ KEYIN ishlatasiz
const getTotal = () => {
  return (
    calculatePrice('extraction') +
    calculatePrice('filling') +
    calculatePrice('crown')
  );
};
  const toothNumbers = {
    topLeft: [18, 17, 16, 15, 14, 13, 12, 11],
    bottomLeft: [48, 47, 46, 45, 44, 43, 42, 41],
    topRight: [21, 22, 23, 24, 25, 26, 27, 28],
    bottomRight: [31, 32, 33, 34, 35, 36, 37, 38]
  };

  const toggleTooth = (category, num) => {
    setSelectedTeeth(prev => {
      const current = prev[category];
      const isSelected = current.includes(num);
      return {
        ...prev,
        [category]: isSelected ? current.filter(t => t !== num) : [...current, num]
      };
    });
  };

  const renderJawHalf = (topNums, bottomNums, category, activeClass) => (
    <div className="jaw-half">
      <div className="tooth-row">
        {topNums.map(num => (
          <div key={num} className="tooth-item">
            <button 
              className={`tooth-btn ${selectedTeeth[category].includes(num) ? activeClass : ''}`}
              onClick={() => toggleTooth(category, num)}
            >
              {num}
            </button>
          </div>
        ))}
      </div>
      <div className="tooth-row">
        {bottomNums.map(num => (
          <div key={num} className="tooth-item">
            <button 
              className={`tooth-btn ${selectedTeeth[category].includes(num) ? activeClass : ''}`}
              onClick={() => toggleTooth(category, num)}
            >
              {num}
            </button>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="dental-container">
      
      <div className="service-row">
        <div className="service-label">
          <h3>Tish Oldirish</h3>
        </div>
        <div className="tooth-section">
          <div className="tooth-grid">
            {renderJawHalf(toothNumbers.topLeft, toothNumbers.bottomLeft, 'extraction', 'red-active')}
            {renderJawHalf(toothNumbers.topRight, toothNumbers.bottomRight, 'extraction', 'red-active')}
          </div>
          <input className="price-box"  value={calculatePrice('extraction').toLocaleString() + " SUM"}  readOnly />
        </div>
      </div>

      {/* 2. Plomba */}
      <div className="service-row">
        <div className="service-label">
          <h3>Plomba</h3>
        </div>
        <div className="tooth-section">
          <div className="tooth-grid">
            {renderJawHalf(toothNumbers.topLeft, toothNumbers.bottomLeft, 'filling', 'blue-active')}
            {renderJawHalf(toothNumbers.topRight, toothNumbers.bottomRight, 'filling', 'blue-active')}
          </div>
          <input 
  className="price-box" 
  value={calculatePrice('filling').toLocaleString() + " SUM"} 
  readOnly 
/>
        </div>
      </div>

      {/* 3. Koronka */}
      <div className="service-row">
        <div className="service-label">
          <h3>Koronka</h3>
        </div>
        <div className="tooth-section">
          <div className="tooth-grid">
            {renderJawHalf(toothNumbers.topLeft, toothNumbers.bottomLeft, 'crown', 'green-active')}
            {renderJawHalf(toothNumbers.topRight, toothNumbers.bottomRight, 'crown', 'green-active')}
          </div>
          <input 
  className="price-box" 
  value={calculatePrice('crown').toLocaleString() + " SUM"} 
  readOnly 
/>
        </div>
      </div>

      <button className="save-btn" onClick={() => console.log("Saqlandi:", selectedTeeth)}>
        Saqlash
      </button>
    </div>
  );
};

export default DentalPage;