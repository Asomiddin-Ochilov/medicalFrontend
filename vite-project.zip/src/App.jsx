import React, { useEffect, useState } from "react";
import { Routes, Route, useNavigate,Navigate } from "react-router-dom";

import axios from "axios";
import { ConfigProvider, message,Spin } from "antd";
import Login from "./pages/Login";
import Dashboard from "./pages/dashboard/Dashboard";
import Patients from "./pages/patients/Patients";
import OnePage from "./pages/patients/onepage";
import AddPatient from "./pages/patients/add";
import AppShell from "./app/AppShell";
import "./styles/base.css";
import SchedulePage from "./pages/calendar/SchedulePage";
import EmployeePage from "./pages/employee/employee";
import PricePage from "./pages/price/price";
import AddHR from "./pages/employee/adduser";
import OneUser from "./pages/employee/oneuser";
import EditUser from "./pages/employee/edituser";
import PriceAdd from "./pages/price/addPrice";
import MessagePage from "./pages/message/message";
import DebtorsPage from "./pages/debtors/debtors";
import OnePageDebtors from "./pages/debtors/onepagedebtors";
import SettingsPage from "./pages/settings/settings";

const theme = {
  token: {
    colorPrimary: "#415FA1",
    borderRadius: 10,
  },
};


function PrivateRoute({ children }) {
  const [checking, setChecking] = useState(true);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchMe = async () => {
      const token = localStorage.getItem("med_auth_token");

      if (!token) {
        setChecking(false);
        return;
      }

      try {
        const res = await axios.get(
          "http://localhost:5000/api/users/me",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        setUser(res.data);
        localStorage.setItem("userData", JSON.stringify(res.data));
      } catch (err) {
        localStorage.removeItem("med_auth_token");
      localStorage.removeItem("userData");
        navigate("/login");
      } finally {
        setChecking(false);
      }
    };

    fetchMe();
  }, [navigate]);

  if (checking) return <div className="loadingApp">
    <Spin size="large" />
  </div>;

  return user ? React.cloneElement(children, { user }) : <Navigate to="/login" replace />;
}

export default function App() {
  
  return (
    <ConfigProvider theme={theme}>
      <div className="app">
        <Routes>
          <Route path="/login" element={<Login />} />

          <Route
            path="/"
            element={
              <PrivateRoute>
                <AppShell   />
              </PrivateRoute>
            }
          >
            <Route index element={<Navigate to="bemorlar" replace />} />

            
            <Route path="users" element={<EmployeePage />} />
            <Route path="users/add" element={<AddHR />} />
            <Route path="users/:id" element={<OneUser />} />
            <Route path="users/:id/edit" element={<EditUser />} />
            <Route path="bemorlar" element={<Patients />} />
            <Route path="kalendar" element={<SchedulePage />} />

            <Route path="message" element={<MessagePage />} />


            <Route path="price" element={<PricePage />} />
            <Route path="price/add" element={<PriceAdd />} />
            
            <Route path="bemorlar/:id" element={<OnePage />} />

            <Route path="bemor-qoshish" element={<AddPatient />} />

            <Route path="dashboard" element={<Dashboard />} />

            <Route path="debtors" element={<DebtorsPage />} />

            <Route path="settings" element={<SettingsPage />} />
            
            <Route path="debtors/:id" element={<OnePageDebtors />} />
          </Route>

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </ConfigProvider>
  );
}
